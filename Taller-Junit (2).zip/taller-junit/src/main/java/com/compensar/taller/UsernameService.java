package com.compensar.taller;
public class UsernameService {
    /**
     * Si el nombre de usuario es "admin" retorna null por seguridad.
     * En otro caso, retorna el mismo nombre recibido.
     */
    public String obtenerUsuario(String username) {
        if (username == null) return null;
        return "admin".equalsIgnoreCase(username) ? null : username;
    }
}
