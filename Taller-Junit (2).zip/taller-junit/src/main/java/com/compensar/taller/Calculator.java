package com.compensar.taller;
public class Calculator {
    public int sumar(int a, int b) {
        return a + b;
    }
}
