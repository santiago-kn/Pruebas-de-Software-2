package com.compensar.taller;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class DiscountCalculator {
    private static final BigDecimal UMBRAL = new BigDecimal("100000");
    private static final BigDecimal DESCUENTO = new BigDecimal("0.10");

    /**
     * Calcula el precio final aplicando 10% de descuento si el precio es >= 100000.
     * Siempre retorna con escala 2 decimales.
     */
    public BigDecimal calcularPrecioFinal(BigDecimal precio) {
        if (precio == null) return null;
        if (precio.compareTo(UMBRAL) >= 0) {
            BigDecimal descuento = precio.multiply(DESCUENTO);
            BigDecimal finalPrice = precio.subtract(descuento);
            return finalPrice.setScale(2, RoundingMode.HALF_UP);
        } else {
            return precio.setScale(2, RoundingMode.HALF_UP);
        }
    }
}
