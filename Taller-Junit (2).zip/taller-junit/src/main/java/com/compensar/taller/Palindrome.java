package com.compensar.taller;
import java.util.Locale;
public class Palindrome {
    public boolean esPalindromo(String texto) {
        if (texto == null) return false;
        String limpio = texto.replaceAll("\\s+", "").toLowerCase(Locale.ROOT);
        int i = 0, j = limpio.length() - 1;
        while (i < j) {
            if (limpio.charAt(i) != limpio.charAt(j)) {
                return false;
            }
            i++; j--;
        }
        return true;
    }
}
