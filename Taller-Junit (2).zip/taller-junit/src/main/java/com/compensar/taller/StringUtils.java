package com.compensar.taller;
public class StringUtils {
    public String concatenar(String a, String b) {
        if (a == null) a = "";
        if (b == null) b = "";
        return a + b;
    }
}
