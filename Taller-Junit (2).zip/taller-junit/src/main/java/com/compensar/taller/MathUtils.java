package com.compensar.taller;
public class MathUtils {
    public long factorial(int n) {
        if (n < 0) throw new IllegalArgumentException("n no puede ser negativo");
        long resultado = 1;
        for (int i = 2; i <= n; i++) {
            resultado *= i;
        }
        return resultado;
    }
}
