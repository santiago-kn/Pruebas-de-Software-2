package com.compensar.taller;
import java.util.List;
public class UserFinder {
    public User buscarPorEmail(List<User> usuarios, String email) {
        if (usuarios == null || email == null) return null;
        for (User u : usuarios) {
            if (email.equalsIgnoreCase(u.getEmail())) {
                return u;
            }
        }
        return null;
    }
}
