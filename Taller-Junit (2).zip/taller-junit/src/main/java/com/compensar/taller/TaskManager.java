package com.compensar.taller;
import java.util.ArrayList;
import java.util.List;

/**
 * Gestor simple de tareas. Si no se ha agregado ninguna tarea,
 * la lista interna permanece en null. Al agregar la primera tarea se inicializa.
 */
public class TaskManager {
    private List<String> tareas = null;

    public void agregarTarea(String tarea) {
        if (tarea == null || tarea.isBlank()) return;
        if (tareas == null) tareas = new ArrayList<>();
        tareas.add(tarea);
    }

    /** Nombre correcto en español. */
    public List<String> obtenerTareas() {
        return tareas;
    }

    /** Método con el "typo" del enunciado por compatibilidad. */
    public List<String> optenerTarea() {
        return tareas;
    }
}
