package com.compensar.taller;
public class PasswordStrength {
    public boolean esFuerte(String password) {
        if (password == null) return false;
        if (password.length() < 8) return false;
        for (char c : password.toCharArray()) {
            if (Character.isDigit(c)) return true;
        }
        return false;
    }
}
