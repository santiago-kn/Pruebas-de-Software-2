package com.compensar.taller;
public class AgeChecker {
    public boolean esMayorDeEdad(int edad) {
        return edad >= 18;
    }
}
