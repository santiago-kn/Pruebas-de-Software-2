package com.compensar.taller;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PalindromeTest {
    @Test
    void reconoceFrasePalindroma() {
        Palindrome p = new Palindrome();
        assertTrue(p.esPalindromo("Anita lava la tina"));
    }
    @Test
    void reconoceNoPalindromo() {
        Palindrome p = new Palindrome();
        assertFalse(p.esPalindromo(" Filokallianthropía"));
    }
    @Test
    void nullDebeSerFalso() {
        Palindrome p = new Palindrome();
        assertFalse(p.esPalindromo(null));
    }
}
