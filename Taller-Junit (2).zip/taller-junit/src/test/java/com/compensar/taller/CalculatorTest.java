package com.compensar.taller;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CalculatorTest {
    @Test
    void sumaDeDosPositivos() {
        Calculator calc = new Calculator();
        int resultado = calc.sumar(7, 5);
        assertEquals(12, resultado);
    }
}
