package com.compensar.taller;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UsernameServiceTest {
    @Test
    void adminDebeRetornarNull() {
        UsernameService service = new UsernameService();
        assertNull(service.obtenerUsuario("admin"));
    }
    @Test
    void otroUsuarioNoDebeSerNull() {
        UsernameService service = new UsernameService();
        assertNotNull(service.obtenerUsuario("john"));
    }
}
