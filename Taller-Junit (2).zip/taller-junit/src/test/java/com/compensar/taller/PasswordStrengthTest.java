package com.compensar.taller;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PasswordStrengthTest {
    @Test
    void contrasenaFuerte() {
        PasswordStrength ps = new PasswordStrength();
        assertTrue(ps.esFuerte("password123"));
    }
    @Test
    void contrasenaDebilPorCorta() {
        PasswordStrength ps = new PasswordStrength();
        assertFalse(ps.esFuerte("pass1"));
    }
    @Test
    void contrasenaDebilPorNoTenerNumeros() {
        PasswordStrength ps = new PasswordStrength();
        assertFalse(ps.esFuerte("passwordlong"));
    }
}
