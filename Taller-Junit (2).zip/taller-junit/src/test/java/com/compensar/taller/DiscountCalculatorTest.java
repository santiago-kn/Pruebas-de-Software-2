package com.compensar.taller;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

public class DiscountCalculatorTest {
    @Test
    void aplicaDescuentoDiezPorcientoCuandoMayorOIgualA100k() {
        DiscountCalculator dc = new DiscountCalculator();
        BigDecimal resultado = dc.calcularPrecioFinal(new BigDecimal("200000"));
        assertEquals(new BigDecimal("180000.00"), resultado);
    }
    @Test
    void noAplicaDescuentoCuandoMenorA100k() {
        DiscountCalculator dc = new DiscountCalculator();
        BigDecimal resultado = dc.calcularPrecioFinal(new BigDecimal("90000"));
        assertEquals(new BigDecimal("90000.00"), resultado);
    }
}
