package com.compensar.taller;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MathUtilsTest {
    @Test
    void factorialDeCincoEs120() {
        MathUtils mu = new MathUtils();
        assertEquals(120L, mu.factorial(5));
    }
    @Test
    void factorialDeCeroEsUno() {
        MathUtils mu = new MathUtils();
        assertEquals(1L, mu.factorial(0));
    }
    @Test
    void factorialDeCincoNoEs121() {
        MathUtils mu = new MathUtils();
        assertNotEquals(121L, mu.factorial(5));
    }
}
