package com.compensar.taller;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

public class UserFinderTest {
    @Test
    void encuentraUsuarioPorEmail() {
        var usuarios = List.of(
            new User("ana@example.com", "ana"),
            new User("juan@example.com", "juan"),
            new User("luis@example.com", "luis")
        );
        UserFinder finder = new UserFinder();
        User encontrado = finder.buscarPorEmail(usuarios, "juan@example.com");
        assertNotNull(encontrado);
        assertEquals("juan", encontrado.getUsername());
    }

    @Test
    void retornaNullSiNoExiste() {
        var usuarios = List.of(
            new User("ana@example.com", "ana"),
            new User("juan@example.com", "juan")
        );
        UserFinder finder = new UserFinder();
        assertNull(finder.buscarPorEmail(usuarios, "nadie@example.com"));
    }
}
