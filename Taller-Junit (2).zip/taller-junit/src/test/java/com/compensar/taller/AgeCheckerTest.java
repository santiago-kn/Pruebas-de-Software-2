package com.compensar.taller;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AgeCheckerTest {
    @Test
    void mayorDeEdad() {
        AgeChecker checker = new AgeChecker();
        assertTrue(checker.esMayorDeEdad(25));
    }
    @Test
    void menorDeEdad() {
        AgeChecker checker = new AgeChecker();
        assertFalse(checker.esMayorDeEdad(17));
    }
}
