package com.compensar.taller;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class StringUtilsTest {
    @Test
    void concatenacionEsperada() {
        StringUtils su = new StringUtils();
        assertEquals("JUnit5", su.concatenar("JUnit", "5"));
    }
    @Test
    void concatenacionNoIgualPorEspacio() {
        StringUtils su = new StringUtils();
        assertNotEquals("hola mundo ", su.concatenar("hola", "mundo"));
    }
}
