package com.compensar.taller;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

public class TaskManagerTest {
    @Test
    void sinTareasDebeRetornarNull() {
        TaskManager tm = new TaskManager();
        assertNull(tm.optenerTarea()); // método con el typo del enunciado
    }
    @Test
    void conTareasNoDebeRetornarNull() {
        TaskManager tm = new TaskManager();
        tm.agregarTarea("Estudiar JUnit");
        List<String> tareas = tm.optenerTarea();
        assertNotNull(tareas);
        assertTrue(tareas.contains("Estudiar JUnit"));
    }
}
