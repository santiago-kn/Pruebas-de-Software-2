# Taller JUnit 5 – Proyecto Maven

## Requisitos
- JDK 21+
- Maven 3.9+

## Ejecutar pruebas
```bash
mvn -q test
```

## Estructura
- `src/main/java/com/compensar/taller/*` – Clases a probar.
- `src/test/java/com/compensar/taller/*` – Pruebas JUnit 5.
- `docs/Explicacion_Taller.md` – Guía paso a paso.
